package Ex2;

public class Box implements ICompute{
	
	private int length, width, height;
	private int volume;
	
	public Box(int length, int width, int height, int volume) {
		super();
		this.length = length;
		this.width = width;
		this.height = height;
		this.volume = volume;
	}
	
	public double calculate() {
		volume = length*width*height;
		return volume;
	}
	
	public void display() {
		System.out.println("volume is :" + volume);
	}
	
	
}
