package Ex2;

public class Person implements ICompute{
	
	private String name;
	private double basicSal;
	private double otRate;
	private double otHrs;
	private double netSal;
	
	public Person(String name, double basicSal, double otRate, double otHrs, double netSal) {
		super();
		this.name = name;
		this.basicSal = basicSal;
		this.otRate = otRate;
		this.otHrs = otHrs;
		this.netSal = netSal;
	}
	
	public double calculate() {
		netSal = basicSal + (otRate*otHrs);
		return netSal;
	}
	
	public void display() {
		System.out.println("Net salary is :" + netSal);
	}
}




