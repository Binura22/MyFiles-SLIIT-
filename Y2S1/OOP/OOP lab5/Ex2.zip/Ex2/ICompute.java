package Ex2;

public interface ICompute {
	double calculate();
	void display();
}
