package Ex3;

import java.io.InputStream;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		int maxSubjects;
		int [] marks = new int[5];
		int total = 0;
		int i;
		double avg;
		try {
		// 1. Input a value for maxSubjects
		// from keyboard
			Scanner sc = new Scanner(System.in);
			System.out.println("Max Subject : ");
			int maxSubject = sc.nextInt();
			
		// 2. Using a for loop
		// input marks
			for(i = 0; i<maxSubject; i++) {
				Scanner sc1 = new Scanner(System.in);
				System.out.println("Max Subject : ");
				marks[i] = sc1.nextInt();
				
				total = total + marks[i];
			}
			// 3. Calculate the avg marks
			avg = total/maxSubject;
			System.out.println("Average is :"+avg);
		
		// 4. Use a try catch block to
		// prevent the following
		// run time errors
		// (a) Input valid integers to the
		// inputs
		// (b) ArithmeticException division
		// by zero
		// (c) ArrayIndexOutOfBounds
		// Exception
		} 
		catch (InputMismatchException e) {
			System.out.println(e);
		}
		
		finally {
		System.out.println("This code will be gurrentied to run");
		}
		System.out.println("The end");
		}

	private static Object netInt(InputStream in) {
		// TODO Auto-generated method stub
		return null;
	}
		
}
