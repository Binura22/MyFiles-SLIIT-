package Ex1;

class Cat extends Animal {
	
	public Cat( ) {
		System.out.println("Cat class constractor");
	}
	
	public Cat(String name) {
		super(name);	
	}
		
	public String speak() {
		return "Meow Meow";
	}

}

