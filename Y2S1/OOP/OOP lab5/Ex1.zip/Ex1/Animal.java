package Ex1;

abstract public class Animal {

	private String name;
	
	public Animal( ) {
		System.out.println("Animal class constractor");
	}
	
	abstract public String speak();
	
	public Animal(String name) {
		super();
		this.name = name;
	}

	public void display() {
		System.out.println("My name is " + this.name + ". " + this.speak() + ".");
	}
}
	

		


