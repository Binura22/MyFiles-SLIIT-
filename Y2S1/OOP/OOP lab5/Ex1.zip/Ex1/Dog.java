package Ex1;

class Dog extends Animal {
	
	public Dog( ) {
		System.out.println("Dog class constractor");
	}
	
	public Dog(String name) {
		super(name);
	}
	
	public String speak() {
		return "Bow Wow";
	}
}
